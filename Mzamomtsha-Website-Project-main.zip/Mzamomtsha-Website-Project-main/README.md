# Mzamomtsha-Website-Project (A brief description of the project)
We the researcher formulated the scope of this project to identify the boundaries of this project. The website, which is going to be the output of the project, is simply going to transition Mzamomtsha Primary School’s method of promoting, informing and handling data to a computerized one such as, allowing the students, parents and visitors to view some information of the institution, recording all the necessary information with regard from the students, has the capability to keep in track the records of the student, allowing parents and students to access anytime they want, and providing features that make the school part of a member’s daily functions.

## A small code example
This is a home page code for the website we have created
<!DOCTYPE html>
<html lang="en">
  
  <title>Mzamomtsha Primary Shool</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.3/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <!-- Load font awesome icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!--Responsive topnav-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel='stylesheet' href='style.css'/>
<!-- Header -->
<div class="header">
  <div class="jumbotron jumbotron-fluid"></class>
 <img src='logow.png' width="150" height="140"/>
 <div class="container">
     <h1>Mzamomtsha Primary School</h1></div>
     <form class="example" action="/action_page.php" style="margin:auto;max-width:300px">
      <input type="text" placeholder="Search.." name="search2">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
</div>
</div> 
<div class="navbar" id="myTopnav">
  <a href="Home.html">Home</a>
  <div class="subnav">
    <button class="subnavbtn">About Us<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="About.html">About</a>
      <a href="Vision.html">Vision</a>
      <a href="mission.html">Mission</a>
      <a href="Find.html">How to Find Us</a>
    </div>
  </div> 
  <div class="subnav">
    <button class="subnavbtn">Events <i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="Sport.html">Sports</a>
      <a href="Culture.html">Culture</a>
      <a href="Music.html">Music</a>
      <a href="SchoolCalender.html">School Calender Events</a>
      <a href="Awards.html">Awards</a>
    </div>
  </div> 
  <div class="subnav">
    <button class="subnavbtn">Alumni<i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
      <a href="News.html">News and Success stories</a>
      <a href="Gallery.html">Photo gallery</a>
    </div>
  </div>
  <div class="subnav">
    <button class="subnavbtn">Staff <i class="fa fa-caret-down"></i></button>
    <div class="subnav-content">
	 <a href="heads.html">Meet our Principal</a>
      <a href="teaching.html">Teaching Staff</a>
      <a href="Social.html">School Governing Body</a>
      <a href="Student.html">Student Leadership</a>
    </div>
  </div>
  <a href="admission.html">Admissions 2024</a>
  <a href="FAQ .html">FAQs</a>

 <a href="javascript:void(0);" class="icon" onclick="myFunction()">
    <i class="fa fa-bars"></i></a>
</div>            
</div>                                                     
  <dv class="main">
   <h2><b>Strive for Excellence</b></h2>
   <br>
    <h1><b>Mzamomtsha Primary School</b></h1>
	<br>
    <h3><b>Since 2007</b></h3>
	<br>
    <h1><a href="Contact.html">
              <button style="border-radius: 12px;" class="Button">
               Contact us
           </button>
           </a>
          </h1>
 <h2>Welcome to Mzamomtsha Primary School Website</h2>
    <p2><center>Here at Mzamomtsha Primary School, your child is more than just a number, each teacher has a personal interest in not only your child’s academics but their overall well-being.     
      <br> We believe in academic standards and discipline, <br>
       offering deep understanding of subjects and passion for chosen course.</center></p2> 
  
       <div class="home">
        <u><h2><strong>Our Values</strong></h2></u>
        <div class="row">
          <div class="col-sm-4">
            <h4><b>Innovation</b></h4>
            <ul>
              <p1>To be open to new ideas and develop creative solutions to problems in a resourceful way</p1>
              
            </ul> 
          </div>
          <div class="col-sm-4">
            <h4><b>Integrity</b></h4>
            <ul>
              <p1>To be honest and do the right thing</p1>
            
            </ul>
          </div>
          <div class="col-sm-4">
            <h4><b>Accountability</b></h4>        
            <ul>
              <p1>We take Responsibility</p1>
            
            </ul>
          </div>
          <div class="col-sm-4">
          <h4><b>Competence</b></h4>
          <ul>
            <p1>The ability and capacity to do the job we were employed to do</p1>
            
          </ul> 
        </div>
        <div class="col-sm-4">
          <h4><b>Responsiveness</b></h4>
          <ul>
            <p1>To serve the needs of our citizens</p1>
          
          </ul>
        </div>
    
    
        <div class="col-sm-4">
          <h4><b>Caring</b></h4>        
          <ul>
            <p1>To care for those we serve and work with</p1>
          
          </ul>
        </div>
          
          <div class="col-sm-4">
            <h4><b>Punctuality</b></h4>  
            <ul>
              <p1>Time once gone is gone forever;We canot retake the lost time</p1>
            </ul>      
          </div>
          <div class="col-sm-4">
            <h4><b>Respect</b></h4>        
            <ul>
              <p1> We treat people with courtesy, politeness, and kindness</p1>
              
            </ul>
          </div>
         
          
          <div class="col-sm-4">
            <h4><b>Loyaty</b></h4>  
            <ul>
              <p1> We are Consistently treating other people with kindness, fairness,and generocity of spirit.</p1>
            
            </ul>      
          </div>
      </div>
  </div>
  </dv>
  
 
</body>
<br>
<br>
<br>
<!--footer-->

<footer>

  <div class="footer">
    <div class="small-print">
      <div class="cont">
        <p><a href="terms.html">Terms & Conditions</a> 
          <a href="privacy.html">Privacy & Policy</a>
           <a href="Contact.html">Contact</a></p>
           <div class="social" style="text-align: center;">
            <a href="https://web.facebook.com/"><img src="facebook.png "  alt="Facebook" width="33px" height="33px"/></a>
            <a href="https://www.instagram.com/?hl=en"> <img src="instagram.png" alt="" width="33px" height="32px"/></a>
            <a href="https://twitter.com/i/flow/login"><img src="twitter.png" alt="" width="40px" height="43px"/></a>
            
           </div>
           <p>Copyright © Mzamomtsha.com 2023 </p></div>
          </div>
          </div>
</Footer>
      <!--Toggle between adding and removing the "responsive" class to topnav when the user clicks on the icon-->
      <script>
        function myFunction() {
        var x = document.getElementById("myTopnav");
        if (x.className === "navbar") {
          x.className += " responsive";
        } else {
          x.className = "navbar";
        }
        }
        </script>
      </html>


## A link to your code & issue tracker
https://comfy-tanuki-3f2314.netlify.app

## Frequently Asked Questions (FAQ)
We have provided a frequently asked questions list to the websites to help users to relate to their question answers 

## How to get support
If you have a suggestion that would make this better, please fork the repo and create a pull request. You can also simply open an issue with the tag "enhancement". Don't forget to give the project a star! Thanks again!

Fork the Project
Create your Feature Branch (git checkout -b feature/AmazingFeature)
Commit your Changes (git commit -m 'Add some AmazingFeature')
Push to the Branch (git push origin feature/AmazingFeature)
Open a Pull Request

## Installation instructions
1. Get a free API Key at https://example.com
2. Clone the repo
git clone https://github.com/github_username/repo_name.git
3. Install NPM packages
npm install
4. Enter your API in config.js
const API_KEY = 'ENTER YOUR API';


## Your project’s license
Distributed under the © 2023 GitHub, and Visual Studio Code https://code.visualstudio.com/
